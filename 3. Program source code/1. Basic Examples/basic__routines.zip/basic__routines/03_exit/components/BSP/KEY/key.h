/**
 ******************************************************************************
 * @file        key.h
 * @version     V1.0
 * @brief       按键驱动代码
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 * 
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

 #ifndef __KEY_H
 #define __KEY_H
 
 #include "freertos/FreeRTOS.h"
 #include "freertos/task.h"
 #include "driver/gpio.h"
 
 /* 引脚定义 */
 #define    KEY0_INT_GPIO_PIN   GPIO_NUM_61
 
 /* 按键按下定义 */
 #define    KEY0_PRES       1    /* KEY0按键按下 */  

  /* IO操作 */
 #define    KEY0_INT            gpio_get_level(KEY0_INT_GPIO_PIN)
 
 /* 函数声明 */
 void key_init(void);            /* 初始化按键 */
 uint8_t key_scan(uint8_t mode); /* 按键扫描函数 */
 
 #endif