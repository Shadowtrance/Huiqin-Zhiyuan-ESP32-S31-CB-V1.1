/**
 ******************************************************************************
 * @file        exit.h
 * @version     V1.0
 * @brief       外部中断驱动代码
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 * 
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#ifndef __EXIT_H
#define __EXIT_H

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"


/* 引脚定义 */
#define   KEY0_INT_GPIO_PIN   GPIO_NUM_61

/* IO操作 */
#define   KEY0_INT    gpio_get_level(KEY0_INT_GPIO_PIN)

/* 函数声明 */
void exit_init(void);   /* 外部中断初始化程序 */

/* 按键中断标志（中断里置1，主循环里处理） */
extern volatile uint8_t key_flag;

#endif
