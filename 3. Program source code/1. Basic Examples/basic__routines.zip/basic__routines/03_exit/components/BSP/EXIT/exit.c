/**
 ******************************************************************************
 * @file        exit.c
 * @version     V1.0
 * @brief       外部中断驱动代码
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 * 
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

 #include "exit.h"
 #include "led.h"

 volatile uint8_t key_flag = 0;    /* 按键中断标志 */

 /**
  * @brief       外部中断服务函数
  * @param       arg:中断引脚信号
  * @note        IRAM_ATTR: 这里的IRAM_ATTR属性用于将中断处理函数存储在内部RAM中，目的在于减少延迟
  * @retval      无
  */
 static void IRAM_ATTR exit_gpio_isr_handler(void *arg)
 {
    uint32_t gpio_num = (uint32_t)arg;
    if(gpio_num == KEY0_INT_GPIO_PIN)
    {
        key_flag = 1;               /*中断里置标志位*/
    }
 }

 /**
  * @brief       外部中断初始化程序
  * @param       无
  * @retval      无
  */
 void exit_init(void)
 {
    gpio_config_t gpio_init_struct = {0};
    gpio_init_struct.mode         = GPIO_MODE_INPUT;            /*输入模式*/
    gpio_init_struct.pull_up_en   = GPIO_PULLUP_ENABLE;         /*上拉使能*/
    gpio_init_struct.pull_down_en = GPIO_PULLDOWN_DISABLE;      /*下拉失能*/
    gpio_init_struct.intr_type    = GPIO_INTR_NEGEDGE;          /*下降沿触发*/
    gpio_init_struct.pin_bit_mask = (1ULL << KEY0_INT_GPIO_PIN);/*使能引脚位掩码*/
    ESP_ERROR_CHECK(gpio_config(&gpio_init_struct));            /*配置使能*/

    /*注册中断服务函数*/
    ESP_ERROR_CHECK(gpio_install_isr_service(0));
    /*设置KEY0按键的中断回调函数*/
    ESP_ERROR_CHECK(gpio_isr_handler_add(KEY0_INT_GPIO_PIN, exit_gpio_isr_handler, (void*) KEY0_INT_GPIO_PIN));
 }
