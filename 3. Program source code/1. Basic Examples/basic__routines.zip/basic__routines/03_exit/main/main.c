/**
 ******************************************************************************
 * @file        main.c
 * @version     V1.0
 * @brief       基础例程
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 * 
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "esp_chip_info.h"
#include <stdio.h>
#include "led.h"
#include "exit.h"

const char* TAG = "main";

/**
 * @brief       程序入口
 * @param       无
 * @retval      无
 */
void app_main(void)
{
    esp_err_t ret;
    uint32_t flash_size;
    uint8_t led_state = 0;           /*LED状态: 0-灭, 1-亮*/
    esp_chip_info_t chip_info;       /*芯片相关信息*/

    ret = nvs_flash_init();          /*初始化NVS*/
    if(ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }

    led_init();       /*初始化LED*/
    exit_init();      /*初始化EXIT*/

    while(1)
    {
        if(key_flag)
        {
            vTaskDelay(pdMS_TO_TICKS(20));        /*消抖延时*/
            if(KEY0_INT == 0)                     /*再次确认按下*/
            {
                led_state = !led_state;
                if(led_state)
                    led_set_rgb(LED_RGB_BLUE);
                else
                    led_off();
            }
            key_flag = 0;                         /*清除标志*/
        }
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}
