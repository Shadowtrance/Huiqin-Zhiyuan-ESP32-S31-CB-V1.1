/**
 ******************************************************************************
 * @file        main.c
 * @version     V1.0
 * @brief       KEY实验
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 * 
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

 #include "freertos/FreeRTOS.h"
 #include "freertos/task.h"
 #include "nvs_flash.h"
 #include <stdio.h>
 #include "led.h"
 #include "key.h"
 
 
 /**
  * @brief       程序入口
  * @param       无
  * @retval      无
  */
 void app_main(void)
 {
	 esp_err_t ret;
	 uint8_t key = 0;
	 uint8_t led_state = 0;      /* LED状态: 0-灭, 1-亮 */

	 ret = nvs_flash_init();     /* 初始化NVS */

	 if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
	 {
		 ESP_ERROR_CHECK(nvs_flash_erase());
		 ESP_ERROR_CHECK(nvs_flash_init());
	 }

	 led_init();                 /* 初始化LED */
	 key_init();                 /* 初始化KEY */

	 while(1)
	 {
		 key = key_scan(0);                  /* 0: 不支持连按, 按下一次只返回一次键值 */

		 if (key == KEY0_PRES)               /* KEY0按键按下 */
		 {
			 led_state = !led_state;         /* 翻转LED状态 */

			 if (led_state)
			 {
				 led_set_rgb(LED_RGB_BLUE);  /* 点亮LED */
			 }
			 else
			 {
				 led_off();                  /* 熄灭LED */
			 }
		 }

		 vTaskDelay(pdMS_TO_TICKS(10));      
	 }
 }
 