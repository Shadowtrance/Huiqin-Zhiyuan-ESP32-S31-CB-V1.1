/**
 ******************************************************************************
 * @file        main.c
 * @version     V1.0
 * @brief       RNG实验
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 * 
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "led.h"
#include "lcd.h"
#include "key.h"
#include "rng.h"
#include <stdio.h>


/**
 * @brief       程序入口
 * @param       无
 * @retval      无
 */
void app_main(void)
{
    esp_err_t ret;
    uint8_t key = 0;
    uint32_t random = 0;
    uint8_t t = 0;

    ret = nvs_flash_init();     /* 初始化NVS */
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }

    led_init();                 /* LED初始化 */
    key_init();                 /* KEY初始化 */
    lcd_init();                 /* LCD屏初始化 */

    lcd_show_string(30, 50,  200, 16, 16, "ESP32-S31", RED);
    lcd_show_string(30, 70,  200, 16, 16, "RNG TEST", RED);
    lcd_show_string(30, 90,  200, 16, 16, "WKS SMART", RED);
    
    lcd_show_string(30, 110, 200, 16, 16, "KEY0:Get", RED);
    lcd_show_string(30, 130, 200, 16, 16, "Random Num:", RED);
    lcd_show_string(30, 150, 200, 16, 16, "Random Num[0-9]:", RED);

    while(1)
    {
        key = key_scan(0);
        
        if (key == KEY0_PRES)    
        {
            random = rng_get_random_num();                      /* 获取随机数 */
            lcd_show_num(118, 130, random, 10, 16, BLUE);
            ESP_LOGI("test", "data:%ld ", random);
        }
        
        if ((t % 20) == 0)                                      
        {                                             
            random = rng_get_random_range(0, 9);                /* 取[0,9]区间的随机数 */
            lcd_show_num(158, 150, random, 1, 16, BLUE);

            led_blink(); 
        }

        vTaskDelay(pdMS_TO_TICKS(10));
        t++;
    }
}
