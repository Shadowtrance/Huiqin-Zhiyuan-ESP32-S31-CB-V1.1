/**
 ******************************************************************************
 * @file        timg.c
 * @version     V2.0
 * @brief       TIMG驱动代码 
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 *
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#include "timg.h"
#include "led.h"
#include "esp_attr.h"

volatile uint8_t led_flag = 1;    /* LED标志位 */
/**
 * @brief       GPTimer回调函数
 * @param       timer: 定时器句柄
 * @param       edata: 警报事件数据
 * @param       user_ctx: 用户数据指针
 * @retval      返回1表示需要高优先级任务唤醒
 */
static bool IRAM_ATTR gptimer_callback(gptimer_handle_t timer, const gptimer_alarm_event_data_t *edata, void *user_ctx)
{
    timg_config_t *user_data = (timg_config_t *) user_ctx;
    /* 存储当前计数值变量清零 */
    user_data->timer_count_value = 0;
    /* 获取当前计数值 */
    user_data->timer_count_value = edata->count_value;
    led_flag = !led_flag;

    /* 如果没有开启重装载，那么想要周期警报，必须设置新警报值 */
    if (!user_data->auto_reload)
    {
        user_data->alarm_value += user_data->timing_time;
        /* 设置新的警报值(ISR版本) */
        gptimer_alarm_config_t alarm_config = {
            .alarm_count = user_data->alarm_value,
        };
        gptimer_set_alarm_action(timer, &alarm_config);
    }

    return 1;
}

/**
 * @brief       初始化GPTimer定时器
 * @param       timg_config: 定时器配置结构体
 * @retval      无
 */
void timg_init(timg_config_t *timg_config)
{
    /* GPTimer配置 — resolution_hz=1000000 表示 1us 分辨率，驱动自动配置分频器 */
    gptimer_config_t gptimer_config = {
        .clk_src = timg_config->clk_src,
        .direction = GPTIMER_COUNT_UP,
        .resolution_hz = 1000000,  /* 1us分辨率 (1MHz) */
    };

    /* 创建GPTimer（计数器从0开始） */
    ESP_ERROR_CHECK(gptimer_new_timer(&gptimer_config, &timg_config->gptimer_handle));

    /* 警报配置 — 新定时器计数器从0开始，首次警报在 timing_time 后触发 */
    gptimer_alarm_config_t alarm_config = {
        .alarm_count = timg_config->timing_time,
        .reload_count = 0,
        .flags.auto_reload_on_alarm = timg_config->auto_reload,
    };
    ESP_ERROR_CHECK(gptimer_set_alarm_action(timg_config->gptimer_handle, &alarm_config));

    /* 注册回调函数 */
    gptimer_event_callbacks_t cbs = {
        .on_alarm = gptimer_callback,
    };
    ESP_ERROR_CHECK(gptimer_register_event_callbacks(timg_config->gptimer_handle, &cbs, timg_config));

    /* 启用定时器 */
    ESP_ERROR_CHECK(gptimer_enable(timg_config->gptimer_handle));
    /* 启动定时器计数（enable 只是上电，start 才开始计数） */
    ESP_ERROR_CHECK(gptimer_start(timg_config->gptimer_handle));
}
