/**
 ******************************************************************************
 * @file        timg.h
 * @version     V1.0
 * @brief       TIMG驱动代码 
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 *
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#ifndef __TIMG_H
#define __TIMG_H


#include "driver/gptimer.h"
#include "esp_clk_tree.h"


/* 定时器配置结构体 */
typedef struct
{
    gptimer_clock_source_t clk_src;     /* 时钟源选择 */
    uint64_t timing_time;               /* 定时时间(us) */
    uint64_t alarm_value;               /* 警报值 */
    bool auto_reload;                   /* 启动自动装载 */
    uint64_t timer_count_value;         /* 计数器当前值 */
    gptimer_handle_t gptimer_handle;    /* GPTimer句柄 */
} timg_config_t;

/* LED标志位 */
extern volatile uint8_t led_flag;

/* 函数声明 */
void timg_init(timg_config_t *timgr_config);

#endif
