/**
 ******************************************************************************
 * @file        main.c
 * @version     V1.0
 * @brief       TIMG实验
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 *
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "esp_log.h"
#include <stdio.h>
#include "led.h"
#include "driver/gptimer.h"
#include "timg.h"


/**
 * @brief       程序入口
 * @param       无
 * @retval      无
 */
void app_main(void)
{
    esp_err_t ret;
    timg_config_t *timgr_config = malloc(sizeof(timg_config_t));

    ret = nvs_flash_init();     /* 初始化NVS */
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }

    led_init();                 /* 初始化LED */

    timgr_config->timer_count_value = 0;                            /* 记录计数值 */
    timgr_config->clk_src           = GPTIMER_CLK_SRC_PLL_F80M;     /* 时钟源选择 */
    timgr_config->timing_time       = 1 * 1000000;                  /* 定时时间(1秒=1000000us) */
    timgr_config->auto_reload       = true;                         /* 自动重装载 */
    timg_init(timgr_config);                                        /* 定时器初始化 */

    while(1)
    {
        if (timgr_config->timer_count_value != 0)
        {
            ESP_LOGI("Timer:", "Timer auto reloaded, count value in ISR: %llu", timgr_config->timer_count_value);
            timgr_config->timer_count_value = 0;    /* 清零 */
        }
        
        led_flag == 1 ? led_set_rgb(LED_RGB_BLUE) : led_off();

        vTaskDelay(pdMS_TO_TICKS(10));              /* 延时10ms */
    }
}
