/**
 ******************************************************************************
 * @file        main.c
 * @version     V1.0
 * @brief       RTC实验
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 * 
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#include "freertos/FreeRTOS.h"
#include "nvs_flash.h"
#include "led.h"
#include "lcd.h"
#include "esp_rtc.h"
#include <stdio.h>


/* 定义字符数组用于显示星期 */
char *weekdays[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

/**
 * @brief       程序入口
 * @param       无
 * @retval      无
 */
void app_main(void)
{
    esp_err_t ret;
    uint8_t tbuf[40];
    uint8_t t = 0;

    ret = nvs_flash_init();     /* 初始化NVS */
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }

    led_init();                 /* LED初始化 */
    lcd_init();                 /* LCD屏初始化 */

    rtc_set_time(2026, 10, 19, 8, 00, 00);   /* 设置RTC时间 */

    lcd_show_string(10, 50,  200, 16, 16, "ESP32-S31", RED);
    lcd_show_string(10, 70,  200, 16, 16, "RTC TEST", RED);
    lcd_show_string(10, 90,  200, 16, 16, "WKS SMART", RED);

    while (1)
    {
        t++;

        if ((t % 10) == 0)      /* 每100ms更新一次显示数据 */
        {
            rtc_get_time();
            sprintf((char *)tbuf, "Time:%02d:%02d:%02d", calendar.hour, calendar.min, calendar.sec);
            lcd_show_string(10, 130, 210, 16, 16, (char *)tbuf,BLUE);
            sprintf((char *)tbuf, "Date:%04d-%02d-%02d", calendar.year, calendar.month, calendar.date);
            lcd_show_string(10, 150, 210, 16, 16, (char *)tbuf,BLUE);
            sprintf((char *)tbuf, "Week:%s", weekdays[calendar.week]);
            lcd_show_string(10, 170, 210, 16, 16, (char *)tbuf,BLUE);
        }

        if ((t % 20) == 0)
        {
            led_blink();
        }

        vTaskDelay(pdMS_TO_TICKS(10));
    }
}
