/**
 ******************************************************************************
 * @file        main.c
 * @version     V1.0
 * @brief       DVP CAMERA实验
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 *
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "lcd.h"
#include "led.h"
#include "dvp_cam.h"


void app_main(void)
{
    esp_err_t ret;

    ret = nvs_flash_init();     /* 初始化NVS */
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }

    lcd_init();                 /* LCD屏初始化 */
    led_init();                 /* LED初始化*/
    dvp_cam_init();             /* 摄像头初始化 */

    while (1)
    {
        led_blink();
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}
