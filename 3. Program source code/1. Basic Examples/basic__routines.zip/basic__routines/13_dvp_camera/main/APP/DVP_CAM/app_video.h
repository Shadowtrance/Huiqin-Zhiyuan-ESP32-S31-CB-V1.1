/**
 ******************************************************************************
 * @file        dvp_video.h
 * @version     V1.0
 * @brief       DVP摄像头初始化
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 *
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#ifndef __APP_VIDEO_H
#define __APP_VIDEO_H

#include "esp_err.h"
#include "linux/videodev2.h"

#include "driver/i2c_master.h"
#include "driver/gpio.h"


/* SCCB (I2C) —— 由esp_video内部构建 */
#define   DVP_SCCB_I2C_PORT           0                  /* I2C端口号 */
#define   DVP_SCCB_I2C_SCL_PIN        1                  /* SCCB SCL引脚 */
#define   DVP_SCCB_I2C_SDA_PIN        0                  /* SCCB SDA引脚 */
#define   DVP_SCCB_I2C_FREQ           100000             /* SCCB时钟频率 */

/* 传感器控制 */
#define   DVP_CAM_SENSOR_RESET_PIN    60                 /* 复位引脚 */
#define   DVP_CAM_SENSOR_PWDN_PIN     (-1)               /* PWDN网络经接地, 不交给驱动管理 */

/* XCLK: 模组自带晶振, 不输出 */
#define   DVP_XCLK_PIN                (-1)
#define   DVP_XCLK_FREQ               20000000

/* DVP并行总线 */
#define   DVP_PCLK_PIN                GPIO_NUM_54        /* 像素时钟 */
#define   DVP_VSYNC_PIN               GPIO_NUM_56        /* 垂直同步 */
#define   DVP_DE_PIN                  GPIO_NUM_57        /* 数据使能(HSYNC) */
#define   DVP_D0_PIN                  GPIO_NUM_46        /* 数据位0 */
#define   DVP_D1_PIN                  GPIO_NUM_47        /* 数据位1 */
#define   DVP_D2_PIN                  GPIO_NUM_48        /* 数据位2 */
#define   DVP_D3_PIN                  GPIO_NUM_49        /* 数据位3 */
#define   DVP_D4_PIN                  GPIO_NUM_50        /* 数据位4 */
#define   DVP_D5_PIN                  GPIO_NUM_51        /* 数据位5 */
#define   DVP_D6_PIN                  GPIO_NUM_52        /* 数据位6 */
#define   DVP_D7_PIN                  GPIO_NUM_53        /* 数据位7 */

/* 图像翻转(0:不翻转;1:翻转) */
#define DVP_CAM_SENSOR_PIC_VFLIP    0                    /* 垂直翻转 */
#define DVP_CAM_SENSOR_PIC_HFLIP    0                    /* 水平翻转 */

typedef enum {
    APP_VIDEO_FMT_RAW8 = V4L2_PIX_FMT_SBGGR8,
    APP_VIDEO_FMT_RAW10 = V4L2_PIX_FMT_SBGGR10,
    APP_VIDEO_FMT_GREY = V4L2_PIX_FMT_GREY,
    APP_VIDEO_FMT_RGB565 = V4L2_PIX_FMT_RGB565,
    APP_VIDEO_FMT_RGB888 = V4L2_PIX_FMT_RGB24,
    APP_VIDEO_FMT_YUV422 = V4L2_PIX_FMT_YUV422P,
    APP_VIDEO_FMT_YUV420 = V4L2_PIX_FMT_YUV420,
} video_fmt_t;


/**
 * @brief Initialize the video application.
 *
 * This function initializes the video application with the given file descriptor
 * and format.
 *
 * @param fd File descriptor for the video device
 * @param init_fmt Initial format for the video device
 * @return
 *    - ESP_OK: Success
 *    - ESP_FAIL: Failure
 */
esp_err_t app_video_init(int fd, video_fmt_t init_fmt);

/**
 * @brief Main function for video application.
 *
 * This function initializes and starts the video application (DVP interface).
 *
 * @return
 *    - ESP_OK: Success
 *    - ESP_FAIL: Failure
 */
esp_err_t app_video_main(i2c_master_bus_handle_t i2c_bus_handle);

/**
 * @brief Open the video device.
 *
 * This function opens the video device on the specified port.
 *
 * @param port Port number for the video device
 * @return
 *    - File descriptor of the opened video device on success
 *    - -1 on failure
 */
int app_video_open(int port);

/**
 * @brief Start the camera stream.
 *
 * This function starts the camera stream using the given file descriptor.
 *
 * @param video_fd File descriptor for the video device
 * @return
 *    - ESP_OK: Success
 *    - ESP_FAIL: Failure
 */
esp_err_t camera_stream_start(int video_fd);

/**
 * @brief Stop the camera stream.
 *
 * This function stops the camera stream using the given file descriptor.
 *
 * @param video_fd File descriptor for the video device
 * @return
 *    - ESP_OK: Success
 *    - ESP_FAIL: Failure
 */
esp_err_t camera_stream_stop(int video_fd);

/**
 * @brief Request buffers for the camera stream.
 *
 * This function requests buffers for the camera stream using the given file descriptor.
 *
 * @param video_fd File descriptor for the video device
 * @param fb_num Number of frame buffers to request
 * @param fb Array of frame buffers
 * @return
 *    - ESP_OK: Success
 *    - ESP_FAIL: Failure
 */
esp_err_t camera_set_bufs(int video_fd, int fb_num, void **fb);

/**
 * @brief Get buffers for the camera stream.
 *
 * This function gets buffers for the camera stream using the given file descriptor.
 *
 * @param fb_num Number of frame buffers to get
 * @param fb Array of frame buffers
 * @return
 *    - ESP_OK: Success
 *    - ESP_FAIL: Failure
 */
esp_err_t camera_get_bufs(int fb_num, void **fb);

/**
 * @brief Get buffer size for the camera stream.
 *
 * This function gets the buffer size for the camera stream using the given file descriptor.
 *
 * @param fb_num Number of frame buffers to get
 * @param size Pointer to the buffer size
 * @return
 *    - ESP_OK: Success
 *    - ESP_FAIL: Failure
 */
uint32_t camera_get_buf_size(int fb_num);


#endif
