/**
 ******************************************************************************
 * @file        dvp_cam.c
 * @version     V1.0
 * @brief       DVP摄像头驱动代码(PPA硬件裁剪 + LCD双缓冲显示)
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 *
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#include "dvp_cam.h"

static const char *dvp_cam_tag = "dvp_cam";

#define ALIGN_UP_BY(num, align)     (((num) + ((align) - 1)) & ~((align) - 1))   /* 向上对齐 */

static void lcd_cam_task(void *arg);

/**
 * @brief       等待一次VSYNC(LCD帧刷新完成)
 * @note        draw_bitmap提交切换后调用,保证DMA已切到新帧缓冲
 * @param       无
 * @retval      无
 */
static void lcd_wait_vsync(void)
{
    refresh_done_flag = 0;
    do
    {
        vTaskDelay(1);
    }
    while (refresh_done_flag != 1);
}

/**
 * @brief       dvp_cam初始化
 * @param       无
 * @retval      ESP_OK:开启成功; ESP_FAIL:开启失败
 */
esp_err_t dvp_cam_init(void)
{
    esp_err_t ret = ESP_OK;

    ret = app_video_main(NULL);                                                  /* 初始化摄像头(DVP), 内部自建SCCB I2C */
    if (ret != ESP_OK)
    {
        ESP_LOGE(dvp_cam_tag, "video main init failed with error 0x%x", ret);
        return ESP_FAIL;
    }

    int video_cam_fd0 = app_video_open(2);                                        /* DVP设备节点 /dev/video2 */
    if (video_cam_fd0 < 0)
    {
        ESP_LOGE(dvp_cam_tag, "video cam open failed");
        return ESP_FAIL;
    }

    ret = app_video_init(video_cam_fd0, APP_VIDEO_FMT_RGB565);                    /* 初始化设备并设置捕获视频格式 */
    if (ret != ESP_OK)
    {
        ESP_LOGE(dvp_cam_tag, "Video cam init failed with error 0x%x", ret);
        return ESP_FAIL;
    }

    /* 文件描述符按值传入任务(不能传局部变量地址: 函数返回后栈帧失效) */
    xTaskCreatePinnedToCore(lcd_cam_task, "lcd cam display", 4096, (void *)(intptr_t)video_cam_fd0, 4, NULL, 0);

    return ESP_OK;
}

/**
 * @brief       摄像头显示任务(PPA硬件裁剪 + LCD双缓冲: 写非显示区, VSYNC时切换)
 * @param       arg: 传入参数(视频文件描述符)
 * @retval      无
 */
static void lcd_cam_task(void *arg)
{
    int video_fd = (int)(intptr_t)arg;                                         /* 任务参数(打开视频设备返回的文件描述符,按值传入) */

    int res = 0;
    struct v4l2_buffer buf;                                                    /* 视频缓冲信息 */
 
    struct v4l2_format format = {0};                                           /* 数据流格式 */
    format.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    /* 获取LCD两帧缓冲(双缓冲: 一块显示时写另一块) */
    void *lcd_fb[2] = {NULL, NULL};
    uint8_t fb_idx = 0;                                                        /* 当前正在显示的帧缓冲索引(lcd_init里lcd_clear已显示fb0) */

    ESP_ERROR_CHECK(esp_lcd_rgb_panel_get_frame_buffer(lcddev.lcd_panel_handle, 2, &lcd_fb[0], &lcd_fb[1]));

    /* 注册PPA客户端(SRM: 由硬件完成画面裁剪和字节交换) */
    ppa_client_handle_t ppa_srm_handle = NULL;
    ppa_client_config_t ppa_srm_config = {
        .oper_type             = PPA_OPERATION_SRM,                            /* PPA操作类型 */
        .max_pending_trans_num = 1,                                            /* 客户端可以持有的最大PPA事务挂起数量 */
    };
    ESP_ERROR_CHECK(ppa_register_client(&ppa_srm_config, &ppa_srm_handle));

    /*  CAM BUF设置两个,使用MMAP */
    void *camera_outbuf[2];
    ESP_ERROR_CHECK(camera_set_bufs(video_fd, 2, NULL));                       /* 设置CAMERA的帧缓存数量 */
    ESP_ERROR_CHECK(camera_get_bufs(2, &camera_outbuf[0]));                    /* 获取CAMERA的帧缓冲 */

    ESP_ERROR_CHECK(camera_stream_start(video_fd));                            /* 开启视频流 */

    if (ioctl(video_fd, VIDIOC_G_FMT, &format) != 0)                           /* 获取驱动实际生效的视频格式 */
    {
        ESP_LOGE(dvp_cam_tag, "get fmt failed");
        return;                                                                /* 拿不到格式就不进入显示循环 */
    }

    uint32_t cam_w = format.fmt.pix.width;
    uint32_t cam_h = format.fmt.pix.height;
    uint32_t lcd_w = lcddev.width;
    uint32_t lcd_h = lcddev.height;
    size_t   cam_buf_size = (size_t)cam_w * cam_h * 2;                         /* 相机单帧大小(RGB565: 2字节/像素) */

    /* 数据cache行大小: PPA要求输出缓冲大小按其对齐 */
    size_t data_cache_line_size = 0;
    esp_cache_get_alignment(MALLOC_CAP_SPIRAM | MALLOC_CAP_DMA, &data_cache_line_size);
    if (data_cache_line_size == 0)
    {
        data_cache_line_size = 1;                           
    }

    /* 两块帧缓冲先整体刷黑: PPA输出覆盖整屏前的短暂时间保持黑底(避免上电瞬间的白屏) */
    for (int i = 0; i < 2; i++)
    {
        memset(lcd_fb[i], 0x00, (size_t)lcd_w * lcd_h * 2);
        Cache_WriteBack_Addr(CACHE_MAP_L1_DCACHE, (uint32_t)lcd_fb[i], lcd_h * lcd_w * 2);
    }

    while (1)
    {
        /* 双缓冲: 只写当前不在显示的那块framebuffer */
        void *draw_buffer = lcd_fb[fb_idx ^ 1];

        memset(&buf, 0, sizeof(buf));
        buf.type   = V4L2_BUF_TYPE_VIDEO_CAPTURE;                              /* 与前面format.type要一致 */
        buf.memory = V4L2_MEMORY_MMAP;                                         /* 内存使用mmap方式 */

        res = ioctl(video_fd, VIDIOC_DQBUF, &buf);                             /* 将已经捕获好视频的内存拉出已捕获视频的队列 */
        if (res != 0)
        {
            ESP_LOGE(dvp_cam_tag, "failed to receive video frame");
            continue;                                                          /* buf无效, 丢弃本次循环 */
        }

        /* 摄像头DMA写入后,先失效缓存: 保证PPA读到本帧最新数据 */
        Cache_Invalidate_Addr(CACHE_MAP_L1_DCACHE, (uint32_t)camera_outbuf[buf.index], cam_buf_size);

        /* PPA配置: 相机画面(800x600)居中裁剪出800x480区域，输出到非显示帧缓冲 */
        ppa_srm_oper_config_t oper_config = {
            .in.buffer          = camera_outbuf[buf.index],                     /* 输入图片数据源 */
            .in.pic_w           = format.fmt.pix.width,                         /* 输入图片的宽度 */
            .in.pic_h           = format.fmt.pix.height,                        /* 输入图片的高度 */
            .in.block_w         = 800,                                          /* 输入块的宽度 */
            .in.block_h         = 480,                                          /* 输入块的高度 */
            .in.block_offset_x  = 0,                                            /* 输入块的X方向偏移 */
            .in.block_offset_y  = 60,                                           /* 输入块的Y方向偏移 */
            .in.srm_cm          = PPA_SRM_COLOR_MODE_RGB565,                    /* 输入图片的色彩模式 */

            .out.buffer         = draw_buffer,                                  /* 输出块的数据源 */
            .out.buffer_size    = ALIGN_UP_BY(lcddev.height * lcddev.width * 16 / 8, data_cache_line_size),   /* 数据源大小 */
            .out.pic_w          = lcddev.width,                                 /* 输出块的宽度 = 屏幕宽 */
            .out.pic_h          = lcddev.height,                                /* 输出块的高度 = 屏幕高 */
            .out.block_offset_x = 0,                                            /* 输出图片的X方向偏移 */
            .out.block_offset_y = 0,                                            /* 输出图片的Y方向偏移 */
            .out.srm_cm         = PPA_SRM_COLOR_MODE_RGB565,                    /* 输出图片的色彩模式 */

            .rotation_angle     = PPA_SRM_ROTATION_ANGLE_0,                     /* 输出图片的旋转角度 */
            .scale_x            = 1.0f,                                         /* 输出图片的X轴缩放因子(1.0: 不缩放) */
            .scale_y            = 1.0f,                                         /* 输出图片的Y轴缩放因子(1.0: 不缩放) */
            .mirror_x           = false,                                        /* 输出图片的X轴镜像选择 */
            .byte_swap          = true,                                         /* 输入数据字节交换(摄像头字节序 -> LCD显示字节序) */
            .mode               = PPA_TRANS_MODE_BLOCKING,                      /* PPA操作执行方式 */
        };

        ESP_ERROR_CHECK(ppa_do_scale_rotate_mirror(ppa_srm_handle, &oper_config));

        /* 写完后刷新缓存,确保LCD DMA读到最新数据 */
        Cache_WriteBack_Addr(CACHE_MAP_L1_DCACHE, (uint32_t)draw_buffer,
                             lcd_h * lcd_w * 2);                                /* RGB565: 每像素2字节 */

        if (ioctl(video_fd, VIDIOC_QBUF, &buf) != 0)                            /* 将空闲的内存加入可捕获视频的队列 */
        {
            ESP_LOGE(dvp_cam_tag, "failed to free video frame");
        }

        /* 请求显示刚写完的帧缓冲(驱动在VSYNC时把DMA切到这块) */
        ESP_ERROR_CHECK(esp_lcd_panel_draw_bitmap(lcddev.lcd_panel_handle, 0, 0, lcd_w, lcd_h, draw_buffer));

        /* 等一次VSYNC: 切换生效后,下一轮写另一块才不会与显示中的帧冲突(消除撕裂) */
        lcd_wait_vsync();

        fb_idx ^= 1;                                    /* 交换显示/写入角色,准备下一帧 */
    }

}
