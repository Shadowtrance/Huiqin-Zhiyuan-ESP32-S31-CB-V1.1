/**
 ******************************************************************************
 * @file        dvp_cam.h
 * @version     V1.0
 * @brief       DVP摄像头驱动代码
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 *
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#ifndef __DVP_CAM_H
#define __DVP_CAM_H

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "app_video.h"
#include "driver/ppa.h"
#include "esp_private/esp_cache_private.h"  
#include "lcd.h"
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/param.h>
#include <sys/errno.h>
#include "esp_log.h"
#include "esp32s31/rom/cache.h"

/* 函数声明 */
esp_err_t dvp_cam_init(void);           /* dvp_cam初始化 */

#endif
