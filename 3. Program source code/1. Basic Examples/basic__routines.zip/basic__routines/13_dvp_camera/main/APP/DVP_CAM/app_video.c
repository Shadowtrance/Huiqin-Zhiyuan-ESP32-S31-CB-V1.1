/**
 ******************************************************************************
 * @file        app_video.c
 * @version     V1.0
 * @brief       摄像头初始化 + V4L2 视频设备封装
 * @details     1. app_video_main()   — 配置 SCCB(I2C) + DVP引脚 → 调用 esp_video_init
 *              2. app_video_open()   — 打开 /dev/video2 设备节点
 *              3. app_video_init()   — 枚举并设置视频格式(RGB565)
 *              4. camera_set_bufs()  — MMAP方式分配帧缓冲
 *              5. camera_stream_start/stop() — 启停视频流
 *              
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 *
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 * 摄像头:       OV5640 DVP (8-bit, 800x600, RGB565)
 ******************************************************************************
 */

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/param.h>
#include <sys/errno.h>
#include "esp_err.h"
#include "esp_log.h"
#include "linux/videodev2.h"
#include "esp_video_init.h"

#include "app_video.h"

static const char *TAG = "app_video";

#define MAX_BUFFER_COUNT                (3)
uint8_t *buffer[MAX_BUFFER_COUNT];
uint32_t buffer_size[MAX_BUFFER_COUNT];

esp_err_t app_video_init(int fd, video_fmt_t init_fmt)
{
    esp_err_t ret = ESP_OK;
    int fmt_index = 0;
    struct v4l2_format init_format;
    struct v4l2_capability capability;
    const int type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
#if DVP_CAM_SENSOR_PIC_VFLIP || DVP_CAM_SENSOR_PIC_HFLIP
    struct v4l2_ext_controls controls;
    struct v4l2_ext_control control[1];
#endif
    if (ioctl(fd, VIDIOC_QUERYCAP, &capability)) {
        ESP_LOGE(TAG, "failed to get capability");
        ret = ESP_FAIL;
        goto exit_0;
    }

    memset(&init_format, 0, sizeof(struct v4l2_format));
    init_format.type = type;
    if (ioctl(fd, VIDIOC_G_FMT, &init_format) != 0) {
        ESP_LOGE(TAG, "failed to get format");
        ret = ESP_FAIL;
        goto exit_0;
    }

    while (1) {
        struct v4l2_fmtdesc fmtdesc = {
            .index = fmt_index++,
            .type = type,
        };

        if (ioctl(fd, VIDIOC_ENUM_FMT, &fmtdesc) != 0) {
            ESP_LOGW(TAG, "enum all fmt");
            ret = ESP_ERR_INVALID_ARG;
            goto exit_0;
        }

        if (fmtdesc.pixelformat != init_fmt) {
            continue;
        }

        struct v4l2_format format = {
            .type = type,
            .fmt.pix.width = init_format.fmt.pix.width,
            .fmt.pix.height = init_format.fmt.pix.height,
            .fmt.pix.pixelformat = fmtdesc.pixelformat,
        };

        if (ioctl(fd, VIDIOC_S_FMT, &format) != 0) {
            if (errno == ESRCH) {
                continue;
            } else {
                ESP_LOGE(TAG, "failed to set format");
                ret = ESP_FAIL;
                goto exit_0;
            }
        }
#if DVP_CAM_SENSOR_PIC_VFLIP
        controls.ctrl_class = V4L2_CTRL_CLASS_USER;
        controls.count      = 1;
        controls.controls   = control;
        control[0].id       = V4L2_CID_VFLIP;
        control[0].value    = 1;
        if (ioctl(fd, VIDIOC_S_EXT_CTRLS, &controls) != 0) {
            ESP_LOGW(TAG, "failed to mirror the frame vertically and skip this step");
        }
#endif

#if DVP_CAM_SENSOR_PIC_HFLIP
        controls.ctrl_class = V4L2_CTRL_CLASS_USER;
        controls.count      = 1;
        controls.controls   = control;
        control[0].id       = V4L2_CID_HFLIP;
        control[0].value    = 1;
        if (ioctl(fd, VIDIOC_S_EXT_CTRLS, &controls) != 0) {
            ESP_LOGW(TAG, "failed to mirror the frame horizontally and skip this step");
        }
#endif

        break;
    }

    return ret;
exit_0:
    close(fd);
    return ret;
}

/**
 * @brief  DVP摄像头主初始化函数
 * @note   使用DVP接口
 *         通过I2C(SCCB)控制摄像头传感器,通过DVP并行总线接收图像数据
 */
esp_err_t app_video_main(i2c_master_bus_handle_t i2c_bus_handle)
{
    esp_err_t ret = ESP_OK;

    esp_video_init_dvp_config_t dvp_config[] = {
        {
            .sccb_config = {
                .init_sccb = true,
                .i2c_config = {
                    .port    = DVP_SCCB_I2C_PORT,
                    .scl_pin = DVP_SCCB_I2C_SCL_PIN,
                    .sda_pin = DVP_SCCB_I2C_SDA_PIN,
                },
                .freq = DVP_SCCB_I2C_FREQ,
            },
            .reset_pin = DVP_CAM_SENSOR_RESET_PIN,
            .pwdn_pin  = DVP_CAM_SENSOR_PWDN_PIN,
            .dvp_pin   = {
                .data_width = CAM_CTLR_DATA_WIDTH_8,
                .data_io = {
                    DVP_D0_PIN,                      /* D0  -> GPIO46 */
                    DVP_D1_PIN,                      /* D1  -> GPIO47 */
                    DVP_D2_PIN,                      /* D2  -> GPIO48 */
                    DVP_D3_PIN,                      /* D3  -> GPIO49 */
                    DVP_D4_PIN,                      /* D4  -> GPIO50 */
                    DVP_D5_PIN,                      /* D5  -> GPIO51 */
                    DVP_D6_PIN,                      /* D6  -> GPIO52 */
                    DVP_D7_PIN,                      /* D7  -> GPIO53 */
                },
                .vsync_io  = DVP_VSYNC_PIN,          /* VSYNC -> GPIO56 */
                .de_io     = DVP_DE_PIN,             /* HSYNC -> GPIO57 */
                .pclk_io   = DVP_PCLK_PIN,           /* PCLK  -> GPIO54 */
                .xclk_io   = DVP_XCLK_PIN,           /* -1 = GPIO_NUM_NC, 模组自带晶振不输出 */
            },
            .xclk_freq = DVP_XCLK_FREQ,
        },
    };

    if (i2c_bus_handle != NULL)
    {
        /* 使用外部已有的I2C总线(其余参数沿用上面的初始化值, 不需要重复赋值) */
        dvp_config[0].sccb_config.init_sccb = false;
        dvp_config[0].sccb_config.i2c_handle = i2c_bus_handle;
    }

    esp_video_init_config_t cam_config = {
        .dvp      = dvp_config,
    };

    ret = esp_video_init(&cam_config);
    return ret;
}

static int video_open(int port)
{
    int ret;
    char name[16];
    int fd = -1;

    ret = snprintf(name, sizeof(name), "/dev/video%d", port);
    if (ret <= 0) {
        return ESP_FAIL;
    }

    fd = open(name, O_RDONLY);
    if (fd < 0) {
        ESP_LOGE(TAG, "Open video %s fail", name);
        return -1;
    }

    return fd;
}

int app_video_open(int port)
{
    int fd = video_open(port);
    if (fd < 0) {
        ESP_LOGE(TAG, "Open video fail");
    }
    return fd;
}

esp_err_t camera_stream_start(int video_fd)
{
    int type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (ioctl(video_fd, VIDIOC_STREAMON, &type)) {
        ESP_LOGE(TAG, "failed to start stream");
        return ESP_FAIL;
    }

    return ESP_OK;
}

esp_err_t camera_stream_stop(int video_fd)
{
    int type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (ioctl(video_fd, VIDIOC_STREAMOFF, &type)) {
        ESP_LOGE(TAG, "failed to stop stream");
        return ESP_FAIL;
    }

    return ESP_OK;
}

esp_err_t camera_set_bufs(int video_fd, int fb_num, void **fb)
{
    if (fb_num > MAX_BUFFER_COUNT) {
        ESP_LOGE(TAG, "buffer num is too large");
        return ESP_FAIL;
    }

    struct v4l2_requestbuffers req;
    int type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    memset(&req, 0, sizeof(req));
    req.count = fb_num;
    req.type = type;

    req.memory = fb ? V4L2_MEMORY_USERPTR : V4L2_MEMORY_MMAP;

    if (ioctl(video_fd, VIDIOC_REQBUFS, &req) != 0) {
        ESP_LOGE(TAG, "req bufs failed");
        goto errout_req_bufs;
    }

    for (int i = 0; i < fb_num; i++) {
        struct v4l2_buffer buf;
        memset(&buf, 0, sizeof(buf));
        buf.type = type;
        buf.memory = req.memory;
        buf.index = i;

        if (ioctl(video_fd, VIDIOC_QUERYBUF, &buf) != 0) {
            ESP_LOGE(TAG, "query buf failed");
            goto errout_req_bufs;
        }

        if (req.memory == V4L2_MEMORY_MMAP) {
            buffer[i] = mmap(NULL, buf.length, PROT_READ | PROT_WRITE, MAP_SHARED, video_fd, buf.m.offset);
            if (buffer[i] == MAP_FAILED) {      /* mmap失败返回MAP_FAILED((void*)-1), 不是NULL */
                ESP_LOGE(TAG, "mmap failed");
                goto errout_req_bufs;
            }
            buffer_size[i] = buf.length;
        } else {
            if (!fb[i]) {
                ESP_LOGE(TAG, "frame buffer is NULL");
                goto errout_req_bufs;
            }
            buf.m.userptr = (unsigned long)fb[i];
            buffer[i] = fb[i];
            buffer_size[i] = buf.length;
        }

        if (ioctl(video_fd, VIDIOC_QBUF, &buf) != 0) {
            ESP_LOGE(TAG, "queue frame buffer failed");
            goto errout_req_bufs;
        }
    }

    return ESP_OK;

errout_req_bufs:
    close(video_fd);
    return ESP_FAIL;
}

esp_err_t camera_get_bufs(int fb_num, void **fb)
{
    if(fb_num > MAX_BUFFER_COUNT) {
        ESP_LOGE(TAG, "buffer num is too large");
        return ESP_FAIL;
    }

    for(int i = 0; i < fb_num; i++) {
        if(buffer[i] != NULL) {
            fb[i] = buffer[i];
        } else {
            ESP_LOGE(TAG, "frame buffer is NULL");
            return ESP_FAIL;
        }
    }

    return ESP_OK;
}

uint32_t camera_get_buf_size(int fb_count)
{
    if(fb_count <= 0 || fb_count > MAX_BUFFER_COUNT) {
        ESP_LOGE(TAG, "buffer num is invalid");
        return 0;
    }

    /* fb_count是缓冲数量, 对应数组下标为fb_count-1 */
    return buffer_size[fb_count - 1];
}
