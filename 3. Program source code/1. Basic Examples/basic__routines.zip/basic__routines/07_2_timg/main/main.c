/**
 ******************************************************************************
 * @file        main.c
 * @version     V1.0
 * @brief       TIMG实验
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 * 
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "esp_log.h"
#include <stdio.h>
#include "led.h"
#include "timg.h"


/**
 * @brief       程序入口
 * @param       无
 * @retval      无
 */
void app_main(void)
{
    esp_err_t ret;

    ret = nvs_flash_init();     /* 初始化NVS */
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }

    led_init();                 /* 初始化LED */

    /* 执行顺序会自动分配定时器 */
    timg_init(500000, 1000000);     /* 定时器0初始化 */
    timg_init(1000000, 1000000);    /* 定时器1初始化 */
    timg_init(2000000, 1000000);    /* 定时器2初始化 */
    timg_init(4000000, 1000000);    /* 定时器3初始化 */

    while(1)
    {
        led_blink();
        vTaskDelay(500);
    }

}
