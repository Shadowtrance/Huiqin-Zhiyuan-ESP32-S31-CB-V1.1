/**
 ******************************************************************************
 * @file        timg.h
 * @version     V1.0
 * @brief       TIMG驱动代码
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 * 
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#ifndef __TIMG_H
#define __TIMG_H

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gptimer.h"
#include "esp_log.h"
#include "../src/gptimer_priv.h"

/* 函数声明 */
uint8_t timg_init(uint64_t alarm_count, uint32_t resolution);       /* 初始化定时器 */

#endif
