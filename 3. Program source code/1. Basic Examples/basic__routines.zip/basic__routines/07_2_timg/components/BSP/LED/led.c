/**
 ******************************************************************************
 * @file        led.c
 * @version     V1.0
 * @brief       WS2812B LED驱动代码
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 * 
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#include "led.h"
#include "led_strip.h"

static led_strip_handle_t g_led_strip = NULL;             /*LED灯带句柄*/
static uint8_t led_flag = 1;                              /* LED状态标志位 */

/**
 * @brief   初始化WS2812B LED
 * @param   无
 * @retval  无
 */
void led_init(void)
{
    /*LED灯带配置*/
    led_strip_config_t strip_config = {
        .strip_gpio_num   = LED_GPIO_PIN,                            /*GPIO引脚号*/     
        .max_leds         = LED_NUM,                                 /*LED数量*/
        .color_component_format = LED_STRIP_COLOR_COMPONENT_FMT_GRB, /*WS2812B像素格式：GRB*/
        .led_model        = LED_MODEL_WS2812,                        /*LED型号*/
        .flags.invert_out = false,                                   /*不反相输出 */
    };

    /*RMT通道配置*/
    led_strip_rmt_config_t rmt_config = {
        .clk_src = RMT_CLK_SRC_DEFAULT,                              /* RMT时钟源：默认 */
        .resolution_hz = 10 * 1000 * 1000,                           /* 10MHz分辨率 */
        .mem_block_symbols = 64,                                     /* RMT内存块大小 */
        .flags.with_dma = true,                                      /* 启用DMA */
    };

    /*创建LED灯带设备*/
    ESP_ERROR_CHECK(led_strip_new_rmt_device(&strip_config, &rmt_config, &g_led_strip));

    /*初始关闭LED*/
    led_off();
}

/**
 * @brief       设置LED颜色
 * @param       red ：红色分量
 * @param       green ：绿色分量
 * @param       blue ：蓝色分量
 * @retval      无
 */
void led_set_color(uint32_t red, uint32_t green, uint32_t blue)
{
    ESP_ERROR_CHECK(led_strip_set_pixel(g_led_strip, 0, red, green, blue));
    ESP_ERROR_CHECK(led_strip_refresh(g_led_strip));
}

/**
 * @brief       设置LED颜色和亮度
 * @param       rgb:颜色值
 * @retval      无
 */
void led_set_rgb(uint32_t rgb)
{
    uint32_t r = (rgb >> 16) & 0xFF;
    uint32_t g = (rgb >> 8) & 0xFF;
    uint32_t b =  rgb & 0xFF;

    r = r * LED_BRIGHTNESS / 255;
    g = g * LED_BRIGHTNESS / 255;
    b = b * LED_BRIGHTNESS / 255;

    led_set_color(r,g, b);
}

/**
 * @brief        闪烁LED
 * @param        无
 * @retval       无
 */
void led_blink(void)
{
    
    led_flag  ? led_set_rgb(LED_RGB_GREEN) : led_set_rgb(LED_RGB_BLACK);
    led_flag = !led_flag;
}

/**
 * @brief        关闭LED
 * @param        无
 * @retval       无
 */
void led_off(void)
{
    led_set_color(0, 0, 0);
}