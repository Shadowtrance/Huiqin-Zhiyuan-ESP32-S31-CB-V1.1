/**
 ******************************************************************************
 * @file        esptimer.h
 * @version     V1.0
 * @brief       高分辨率定时器（ESP定时器）驱动代码
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 * 
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#ifndef __ESPTIMER_H
#define __ESPTIMER_H

#include "esp_timer.h"

/*led 标志位*/
extern volatile uint8_t led_flag;

/* 函数声明 */
void esptimer_init(uint64_t tps);   /* 初始化高分辨率定时器 */

#endif
