/**
 ******************************************************************************
 * @file        main.c
 * @version     V1.0
 * @brief       ESPTIMER实验
 ******************************************************************************
 * @attention   Waiken-Smart 慧勤智远
 * 
 * 实验平台:     慧勤智远 ESP32-S31 开发板
 ******************************************************************************
 */

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include <stdio.h>
#include "led.h"
#include "esptimer.h"


/**
 * @brief       程序入口
 * @param       无
 * @retval      无
 */
void app_main(void)
{
    esp_err_t ret;
    
    ret = nvs_flash_init();     /* 初始化NVS */

    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }

    led_init();                 /* 初始化LED */
    esptimer_init(1000000);     /* 初始化ESP_TIMER */

    while(1)
    {
        
        led_flag  ? led_set_rgb(LED_RGB_RED) : led_set_rgb(LED_RGB_BLUE);

        vTaskDelay(pdMS_TO_TICKS(10));  /* 延时10ms */
    }
}
